class Note {
  DateTime time;
  String title;
  String descrip;

  Note({
    required this.time,
    required this.title,
    required this.descrip,
  });
}
